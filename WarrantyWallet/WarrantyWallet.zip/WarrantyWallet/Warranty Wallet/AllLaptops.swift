//
//  AllLaptops.swift
//  Warranty Wallet
//
//  Created by Zaeni Hoque on 12/6/19.
//  Copyright © 2019 Zaeni Hoque. All rights reserved.
//

import UIKit

class AllLaptops: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var datas: [ItemDetail] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datas = createArray()
        
        tableView.delegate = self
        tableView.dataSource = self

    }
    
    func createArray() -> [ItemDetail] {
        
//        var tempData: [ItemDetail] = []
        
        let data1 = ItemDetail(itemName: "iPhone", itemCategory: "Phones")
        let data2 = ItemDetail(itemName: "Dell Laptop", itemCategory: "Laptops")
        let data3 = ItemDetail(itemName: "Dell Laptop 2", itemCategory: "Laptops")
        let data4 = ItemDetail(itemName: "Dell Laptop 3", itemCategory: "Laptops")
        
//        tempData.append(data1)
//        tempData.append(data2)
//        tempData.append(data3)
//        tempData.append(data4)
        
        return [data1, data2, data3, data4]
    }
    
}

extension AllLaptops: UITableViewDataSource, UITableViewDelegate {
    
    func tableView (_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return datas.count
    }
    
    func tableView (_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let detail = datas[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableCell") as! LaptopAdapterTableViewCell
        
        cell.setDetails(details: detail)
        
        return cell
    }
}
