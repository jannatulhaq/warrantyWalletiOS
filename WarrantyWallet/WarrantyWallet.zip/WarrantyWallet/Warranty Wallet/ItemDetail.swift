//
//  ItemDetail.swift
//  Warranty Wallet
//
//  Created by Zaeni Hoque on 12/6/19.
//  Copyright © 2019 Zaeni Hoque. All rights reserved.
//

import Foundation
import UIKit

class ItemDetail{
    
    var itemName: String
    var itemCategory: String
    
    init(itemName: String, itemCategory: String)
    {
        self.itemName = itemName
        self.itemCategory = itemCategory
    }
    
    
}
