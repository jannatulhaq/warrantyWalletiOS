//
//  LaptopAdapterTableViewCell.swift
//  Warranty Wallet
//
//  Created by Zaeni Hoque on 12/6/19.
//  Copyright © 2019 Zaeni Hoque. All rights reserved.
//

import UIKit

class LaptopAdapterTableViewCell: UITableViewCell {

    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var itemCategory: UILabel!
    
    func setDetails(details: ItemDetail)
    {
        itemName.text = details.itemName
        itemCategory.text = details.itemCategory
    }
}
